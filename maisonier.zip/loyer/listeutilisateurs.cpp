#include "listeutilisateurs.h"
#include "ui_listeutilisateurs.h"
#include "updateuser.h"

ListeUtilisateurs::ListeUtilisateurs(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ListeUtilisateurs)
{
    ui->setupUi(this);
    this->setWindowTitle("Liste des Utilisateurs");

    model = new QSqlQueryModel;
    model->setQuery("SELECT id_user, nom_complet, tel, login, nbre_connex FROM utilisateur");

    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOM COMPLET"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("TELEPHONE"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("LOGIN"));
//    model->setHeaderData(4, Qt::Horizontal, QObject::tr("MOT DE PASSE"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("NOMBRE DE CONNEXION"));
    model->setHeaderData(6, Qt::Horizontal, QObject::tr("DATE DE DERNIERE CONNEXION"));
    model->setHeaderData(7, Qt::Horizontal, QObject::tr("DATE DE DERNIERE DECONNEXION"));

    this->ui->tableView->setModel(model);

}

ListeUtilisateurs::~ListeUtilisateurs()
{
    delete ui;
}

void ListeUtilisateurs::on_modifier_clicked()
{
    QItemSelectionModel *selection = this->ui->tableView->selectionModel();
    QModelIndexList indexes = selection->selectedIndexes();
    QModelIndex index = indexes.at(0);
    QVariant element = model->data(index, Qt::DisplayRole);
    //qDebug() << element.toInt();

    int id = element.toInt();
    UpdateUser *userIHM = new UpdateUser;
    userIHM->ihmshow(id);
    userIHM->setWindowModality(Qt::ApplicationModal);
    userIHM->setVisible(true);
    this->close();
}

void ListeUtilisateurs::on_supprimer_clicked()
{
    QItemSelectionModel *selection = this->ui->tableView->selectionModel();
    QModelIndexList indexes = selection->selectedIndexes();
    QModelIndex index = indexes.at(0);
    QVariant element = model->data(index, Qt::DisplayRole);
    //qDebug() << element.toInt();

    int id = element.toInt();
    UpdateUser *userIHM = new UpdateUser;
    userIHM->ihmDelete(id);
    userIHM->setWindowModality(Qt::ApplicationModal);
    userIHM->setVisible(true);
    this->close();
}
