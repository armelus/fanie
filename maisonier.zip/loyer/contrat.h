#ifndef CONTRAT_H
#define CONTRAT_H

#include <QWidget>
#include <QLineEdit>
#include <QDateTimeEdit>
#include <QTextEdit>
#include <QFormLayout>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QCloseEvent>
#include <QSqlQuery>
#include <QSqlError>
#include <QCryptographicHash>
#include <QString>
#include <QByteArray>
#include <QMessageBox>
#include <QDebug>
#include <QSql>
#include <QSqlQuery>
#include <QString>
#include <QSqlTableModel>
#include <QSqlQueryModel>
#include <QSqlRelationalTableModel>
#include <QTableView>
#include <QCheckBox>
#include <QDialog>
#include <QComboBox>
#include <string>
#include <vector>

using namespace std;

namespace Ui {
class Contrat;
}

class Contrat : public QWidget
{
    Q_OBJECT

public:
    explicit Contrat(int idUser, QWidget *parent = 0);
    ~Contrat();
    void initializeView();
    void ihmInsert();
    void ihmUpdate();
    void supprimer();
    void resilier();
    void renouveler();

private slots:
    void on_ajouter_clicked();
    void on_modifier_clicked();
    void on_supprimer_clicked();
    void enregistrer();
    void update();

    void on_resilier_clicked();

    void on_renouveler_clicked();

private:
    Ui::Contrat *ui;
    int id_user;
    int id_contrat;
    int id_occupation;
    QSqlRelationalTableModel *model;
    QWidget *fenetre;
    QComboBox *occupations;
    QDateEdit *DateCreation;
    QDateEdit *DateResiliation;
    QLineEdit *montantMensuel;
    QDateEdit *DateRenouvellement;
    QPushButton *btn_renitial;
    QPushButton *btn_enreg;
    QPushButton *btn_fermer;
    QHBoxLayout *cadreHbtn;
    QVBoxLayout *cadrev;
    QFormLayout *mon_form;
};

#endif // CONTRAT_H
