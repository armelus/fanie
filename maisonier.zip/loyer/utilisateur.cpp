#include "utilisateur.h"
#include "accueil.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QCryptographicHash>
#include <QString>
#include <QByteArray>
#include <QMessageBox>
#include <QDebug>

Utilisateur::Utilisateur(QString t, QWidget *parent)
{
    LEdit_nom =new QLineEdit;
    LEdit_login =new QLineEdit;
    LEdit_password = new QLineEdit;
    LEdit_passwordC = new   QLineEdit;
    LEdit_tel = new QLineEdit;
    btn_renitial = new QPushButton("Rénitialiser");
    btn_enreg = new QPushButton("Enregistrer");
    btn_fermer = new QPushButton("Fermer") ;
    cadreHbtn = new QHBoxLayout;
    cadrev = new QVBoxLayout;
    mon_form = new QFormLayout;



    //paramétrage du nom
    LEdit_nom->setMaxLength(50);
    LEdit_nom->setPlaceholderText("votre nom complet");

    //paramétrage du login
    LEdit_login->setMaxLength(50);
    LEdit_login->setPlaceholderText(" Votre Login");

    //paramétrage des mot de passe

    LEdit_password->setMaxLength(15);
    LEdit_password->setEchoMode(QLineEdit::Password);
    LEdit_passwordC->setMaxLength(15);
    LEdit_passwordC->setEchoMode(QLineEdit::Password);

    //paramétrage du teléphone
    LEdit_tel->setMaxLength(9);
    LEdit_tel->setInputMask("999999999");
    LEdit_tel->setToolTip("saisisez votre numéro de téléphone");

    mon_form->addRow("Nom Complet", LEdit_nom);
    mon_form->addRow("login", LEdit_login);
    mon_form->addRow("mot de passe", LEdit_password);
    //mon_form->addRow("confirmation du mot de passe ", LEdit_passwordC);
    mon_form->addRow("votre numéro de téléphone",LEdit_tel);


    cadreHbtn->addWidget(btn_renitial);
    cadreHbtn->addWidget(btn_enreg);
    cadreHbtn->addWidget(btn_fermer);


    cadrev->addLayout(mon_form);
    cadrev->addLayout(cadreHbtn);


    this->setWindowTitle(t);
    this->setLayout(cadrev);
    this->setFixedSize(400,400);


    //parametrage des connexion
    connect(btn_renitial,SIGNAL(clicked()),this,SLOT(Renitialiser()));
    connect(btn_enreg,SIGNAL(clicked()),this,SLOT(EnvoyerForm()));
    connect(btn_fermer,SIGNAL(clicked()),this,SLOT(GestionFermeture()));
}


void Utilisateur::Renitialiser()
{
    int rep=QMessageBox::question(this,"confirmation de la réinitialisation du formulaire","voulez-vous vraiment effacer les informations saisies?",QMessageBox::Yes|QMessageBox::No|QMessageBox::Cancel,QMessageBox::Cancel);

    if(rep==QMessageBox::Yes)
    {

        LEdit_nom->clear();
        LEdit_login->clear();
        LEdit_password->clear();
        //LEdit_passwordC->clear();
        LEdit_tel->clear();
        LEdit_nom->setFocus();
    }
}


void Utilisateur::EnregForm()
{
    QString msg="voici vos informations:\nNom: "+LEdit_nom->text()+"\nLogin: "+LEdit_login->text()+"\nTeléphone: "+LEdit_tel->text()+"\nvoulez_vous vraiment enregistrez?";

    int rep=QMessageBox::question(this,"confirmation de l'enregistrement",msg,QMessageBox::Yes|QMessageBox::No|
                                  QMessageBox::Cancel,QMessageBox::Yes);

    if(rep==QMessageBox::Yes)
    {
        //instruction d'écriture dans la BD

    }
}


void Utilisateur::EnvoyerForm()
{

    QString nom1= LEdit_nom->text();
    QString login1 = LEdit_login->text();
    QString pass1=LEdit_password->text();
    // QString pass2=LEdit_passwordC->text();
    QString tel1=LEdit_tel->text();

    pass1= QString("%1").arg(QString(QCryptographicHash::hash(LEdit_password->text().toUtf8(),QCryptographicHash::Md5).toHex()));

    qDebug() << pass1;

    if(nom1.isEmpty()|| login1.isEmpty()|| pass1.isEmpty())
        QMessageBox::information(this,"Erreur de saisie","Veuillez remplir tous les champs...",QMessageBox::Ok);
    else
    {

        //instruction d'écriture dans la BD
        QSqlQuery rek;

        rek.prepare("insert into utilisateur(nom_complet, tel, login, mot_depasse)VALUES (:nom,:tel,:login, :pass)");
        rek.bindValue(":nom",nom1);
        rek.bindValue(":tel",tel1);
        rek.bindValue(":login",login1);
        rek.bindValue(":pass",pass1);

        if(rek.exec())
        {
            rek.next();
            QMessageBox::information(this,"Enregistrement de l'utilisateur","Inscription réussie",QMessageBox::Ok);

            this->close();
            accueil *p;
            p=new accueil;
            p->setVisible(false);
        }
        else
        {
            // QMessageBox::information(this,"Erreur","Echec D'enregistrement",QMessageBox::Ok);
            qDebug() << rek.lastError().text();
        }
        // }
    }
}


void Utilisateur::GestionFermeture()
{
    {
        this->close();
    }

}

void Utilisateur::closeEvent(QCloseEvent *evt)
{
    int choix=QMessageBox::question(this,"confirmation de la fermeture","voulez_vous vraiment fermer cette fenetre?",
                                    QMessageBox::Yes|QMessageBox::No,QMessageBox::No);

    if(choix==QMessageBox::Yes)
    {
        evt->accept();//accepter la fermeture
    }
    else
        evt->ignore();


}

void Utilisateur::UpdateUtilisateur(int idUser, QString t, QWidget *parent)
{
    LEdit_nom =new QLineEdit;
    LEdit_login =new QLineEdit;
   // LEdit_password = new QLineEdit;
    //LEdit_passwordC = new   QLineEdit;
    LEdit_tel = new QLineEdit;
    btn_renitial = new QPushButton("Rénitialiser");
    btn_enreg = new QPushButton("Enregistrer");
    btn_fermer = new QPushButton("Fermer") ;
    cadreHbtn = new QHBoxLayout;
    cadrev = new QVBoxLayout;
    mon_form = new QFormLayout;

    /*
     * Get Datas from database
     */

    QSqlQuery query;
    query.prepare("SELECT * FROM utilisateur WHERE id_user = :id");
    query.bindValue(":id", idUser);

    int id;
    QString name;
    int tel;
    QString login;

    if(query.exec())
    {
        while(query.next())
        {
            id = query.value(0).toInt();
            name = query.value(1).toString();
            tel = query.value(2).toInt();
            login = query.value(3).toString();
        }
    }

    //paramétrage du nom
    LEdit_nom->setMaxLength(50);
    //LEdit_nom->setPlaceholderText("votre nom complet");
    LEdit_nom->setText(name);

    //paramétrage du login
    LEdit_login->setMaxLength(50);
    //LEdit_login->setPlaceholderText(" Votre Login");
    LEdit_login->setText(login);

    //paramétrage du teléphone
    LEdit_tel->setMaxLength(9);
    LEdit_tel->setInputMask("999999999");
    LEdit_tel->setToolTip(QString::number(tel));
    //LEdit_tel->setText(QString::number(tel));

    mon_form->addRow("Nom Complet", LEdit_nom);
    mon_form->addRow("login", LEdit_login);
   // mon_form->removeWidget(LEdit_password);
    //mon_form->addRow("mot de passe", LEdit_password);
    //mon_form->addRow("confirmation du mot de passe ", LEdit_passwordC);
    mon_form->addRow("votre numéro de téléphone",LEdit_tel);


    cadreHbtn->addWidget(btn_renitial);
    cadreHbtn->addWidget(btn_enreg);
    cadreHbtn->addWidget(btn_fermer);


    cadrev->addLayout(mon_form);
    cadrev->addLayout(cadreHbtn);


    this->setWindowTitle(t);
    this->setLayout(cadrev);
    this->setFixedSize(400,400);


    //parametrage des connexion
    connect(btn_renitial,SIGNAL(clicked()),this,SLOT(Renitialiser()));
    connect(btn_enreg,SIGNAL(clicked()),this,SLOT(EnvoyerForm()));
    connect(btn_fermer,SIGNAL(clicked()),this,SLOT(GestionFermeture()));

}

void Utilisateur::UpdateUser()
{
    QString nom1= LEdit_nom->text();
    QString login1 = LEdit_login->text();
    QString pass1=LEdit_password->text();
    // QString pass2=LEdit_passwordC->text();
    QString tel1=LEdit_tel->text();

    pass1= QString("%1").arg(QString(QCryptographicHash::hash(LEdit_password->text().toUtf8(),QCryptographicHash::Md5).toHex()));

    qDebug() << pass1;

    if(nom1.isEmpty()|| login1.isEmpty()|| pass1.isEmpty())
        QMessageBox::information(this,"Erreur de saisie","Veuillez remplir tous les champs...",QMessageBox::Ok);
    else
    {

        //instruction d'écriture dans la BD
        QSqlQuery rek;

        rek.prepare("insert into utilisateur(nom_complet, tel, login, mot_depasse)VALUES (:nom,:tel,:login, :pass)");
        rek.bindValue(":nom",nom1);
        rek.bindValue(":tel",tel1);
        rek.bindValue(":login",login1);
        rek.bindValue(":pass",pass1);

        if(rek.exec())
        {
            rek.next();
            QMessageBox::information(this,"Enregistrement de l'utilisateur","Inscription réussie",QMessageBox::Ok);

            this->close();
            accueil *p;
            p=new accueil;
            p->setVisible(false);
        }
        else
        {
            // QMessageBox::information(this,"Erreur","Echec D'enregistrement",QMessageBox::Ok);
            qDebug() << rek.lastError().text();
        }
        // }
    }
}
