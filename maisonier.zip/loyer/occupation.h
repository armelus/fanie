#ifndef OCCUPATION_H
#define OCCUPATION_H

#include <QWidget>
#include <QLineEdit>
#include <QDateTimeEdit>
#include <QTextEdit>
#include <QFormLayout>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QCloseEvent>
#include <QSqlQuery>
#include <QSqlError>
#include <QCryptographicHash>
#include <QString>
#include <QByteArray>
#include <QMessageBox>
#include <QDebug>
#include <QSql>
#include <QSqlQuery>
#include <QString>
#include <QSqlTableModel>
#include <QSqlQueryModel>
#include <QTableView>
#include <QCheckBox>
#include <QDialog>
#include <QComboBox>
#include <string>

namespace Ui {
class Occupation;
}

class Occupation : public QWidget
{
    Q_OBJECT

public:
    explicit Occupation(int idUser, QWidget *parent = 0);
    ~Occupation();
    void ihmNewOccupation(QWidget *parent = 0, QString title = "Créer une occupation");
    void ihmUpdate(QString title = "Modifier une occupation");
    void supprimer();
    void initializeView();

private:
    Ui::Occupation *ui;
    int id_user;
    int id_habit;
    int id_occupation;
    double prixMin;
    double prixMax;
    QSqlTableModel *model;

    QWidget *fenetre;
    QComboBox *habitants;
    QComboBox *logements;
    QLineEdit *LoyerBase;
    QDateEdit *DateEntree;
    QDateEdit *DateSortie;
    QLineEdit *arriere;
    QTextEdit *Description;
    QCheckBox *etat;
    QPushButton *btn_renitial;
    QPushButton *btn_enreg;
    QPushButton *btn_fermer;
    QHBoxLayout *cadreHbtn;
    QVBoxLayout *cadrev;
    QFormLayout *mon_form;

private slots:
    void on_ajouter_clicked();
    void on_modifier_clicked();
    void on_supprimer_clicked();
    void enregistrer();
    void update();
};

#endif // OCCUPATION_H
