#include "fenprincipale.h"

FenPrincipale::FenPrincipale(QString e, QWidget *parent):QMainWindow(parent)
{
    // Création des variables dynamiques(pointeurs)
    Btn_connect = new QPushButton;
    Btn_Quitter = new QPushButton;
    CadreF = new QFormLayout;
    WidgetFen = new QWidget;


    // Paramétrage des boutons
    // Paramétrage du bouton Btn_connect
    Btn_connect->setText("Connectez-vous!!!");
    Btn_connect->setToolTip("Cliquez ici pour vous connecter à votre compte");

    // Paramétrage du bouton Btn_Quitter
    Btn_Quitter->setText("Quitter l'application");
    Btn_Quitter->setToolTip("Cliquez ici pour quitter l'application");


    //Paramétrage du cadre formulaire
    CadreF->addRow(Btn_connect);
    CadreF->addRow(Btn_Quitter);


    // Paramétrage du Widget de la fenêtre.
    WidgetFen->setLayout(CadreF);


    //Paramétrage de la fenêtre.
    this->setWindowTitle(e);
    this->setCentralWidget(WidgetFen);
    this->setFixedSize(220,70);




    // Paramétrage des connexions
    connect(Btn_Quitter,SIGNAL(clicked()),this,SLOT(close()));// this c'est le receptur du message(notre fenêtre).
    connect(Btn_connect,SIGNAL(clicked()),this,SLOT(AfficheAuthentification()));
    //connect(ActionQuit,SIGNAL(triggered()),this,SLOT(close()));//triggered est le signal revoyé par une action quand on la sélectionne
    //connect(ActionAbout,SIGNAL(triggered()),this,SLOT(close()));
}

/*
void FenPrincipale::closeEvent(QCloseEvent *evt)
    {
        int choix;
        //change voir tara: information; warning, question; critical.
        choix=QMessageBox::information(this,"Confirmation de fermeture","Voulez vous vraiment fermer l'application?",QMessageBox::Yes|QMessageBox::No|QMessageBox::Cancel,QMessageBox::Cancel);
        //evt->ignore();//ignore ou refuse la fermeture
        if(choix == QMessageBox::Yes)
            evt->accept();//Accepte la fermétture.
        else
            evt->ignore();//Ignore la férmeture.
    }*/



void FenPrincipale::AfficheAuthentification()
{
    Authentification *t;
    t=new Authentification;
    t->setWindowModality(Qt::ApplicationModal);// ça bloque la fenêtre qui l'a appelé.

    t->setVisible(true);
    this->close();
}

