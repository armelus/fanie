#include "updateuser.h"
#include "listeutilisateurs.h"

UpdateUser::UpdateUser(QString t, QWidget *parent)
{
    LEdit_nom =new QLineEdit;
    LEdit_login =new QLineEdit;
   // LEdit_password = new QLineEdit;
    //LEdit_passwordC = new   QLineEdit;
    LEdit_tel = new QLineEdit;
    btn_renitial = new QPushButton("Rénitialiser");
    btn_enreg = new QPushButton("Enregistrer");
    btn_fermer = new QPushButton("Fermer") ;
    cadreHbtn = new QHBoxLayout;
    cadrev = new QVBoxLayout;
    mon_form = new QFormLayout;

}

void UpdateUser::ihmshow(int idUser, QString t, QWidget *parent)
{
    this->id_user = idUser;
    /*
     * Get Datas from database
     */

    QSqlQuery query;
    query.prepare("SELECT * FROM utilisateur WHERE id_user = :id");
    query.bindValue(":id", idUser);

    int id;
    QString name;
    int tel;
    QString login;

    if(query.exec())
    {
        while(query.next())
        {
            id = query.value(0).toInt();
            name = query.value(1).toString();
            tel = query.value(2).toInt();
            login = query.value(3).toString();
        }
    }

    //paramétrage du nom
    LEdit_nom->setMaxLength(50);
    //LEdit_nom->setPlaceholderText("votre nom complet");
    LEdit_nom->setText(name);

    //paramétrage du login
    LEdit_login->setMaxLength(50);
    //LEdit_login->setPlaceholderText(" Votre Login");
    LEdit_login->setText(login);

    //paramétrage du teléphone
    LEdit_tel->setMaxLength(9);
    LEdit_tel->setInputMask("999999999");
    //LEdit_tel->setToolTip(QString::number(tel));
    LEdit_tel->setText(QString::number(tel));

    mon_form->addRow("Nom Complet", LEdit_nom);
    mon_form->addRow("login", LEdit_login);
   // mon_form->removeWidget(LEdit_password);
    //mon_form->addRow("mot de passe", LEdit_password);
    //mon_form->addRow("confirmation du mot de passe ", LEdit_passwordC);
    mon_form->addRow("votre numéro de téléphone",LEdit_tel);


    cadreHbtn->addWidget(btn_renitial);
    cadreHbtn->addWidget(btn_enreg);
    cadreHbtn->addWidget(btn_fermer);


    cadrev->addLayout(mon_form);
    cadrev->addLayout(cadreHbtn);


    this->setWindowTitle(t);
    this->setLayout(cadrev);
    this->setFixedSize(400,400);

    //parametrage des connexion
//    connect(btn_renitial,SIGNAL(clicked()),this,SLOT(Renitialiser()));
    connect(btn_enreg,SIGNAL(clicked()),this,SLOT(envoyerForm()));
  //  connect(btn_fermer,SIGNAL(clicked()),this,SLOT(GestionFermeture()));
}

void UpdateUser::envoyerForm()
{
    QString nom1= LEdit_nom->text();
    QString login1 = LEdit_login->text();
    QString tel1=LEdit_tel->text();

    if(nom1.isEmpty()|| login1.isEmpty() || tel1.isEmpty())
        QMessageBox::information(this,"Erreur de saisie","Veuillez remplir tous les champs...",QMessageBox::Ok);
    else
    {

        //instruction d'écriture dans la BD
        QSqlQuery rek;

        rek.prepare("update utilisateur set nom_complet = :nom, tel = :tel, login = :login WHERE id_user = :id");
        rek.bindValue(":nom",nom1);
        rek.bindValue(":tel",tel1);
        rek.bindValue(":login",login1);
        rek.bindValue(":id", this->id_user);

        if(rek.exec())
        {
            rek.next();
            QMessageBox::information(this,"Mis a jour de l'utilisateur","Mis a jour réussie",QMessageBox::Ok);
            this->close();
        }
        else
        {
            // QMessageBox::information(this,"Erreur","Echec D'enregistrement",QMessageBox::Ok);
            qDebug() << rek.lastError().text();
        }
        // }
    }
}

void UpdateUser::ihmDelete(int iduser, QString t, QWidget *parent)
{
    int reponse  = QMessageBox::question(this, t, "Etes-vous sur de vouloir supprimer cet utilisateur ?", QMessageBox::Yes | QMessageBox::No, QMessageBox::No);

    if(reponse == QMessageBox::Yes)
    {
        QSqlQuery query;

        query.prepare("delete from utilisateur where id_user = :id");
        query.bindValue(":id", iduser);
        if(query.exec())
        {
            QMessageBox::information(this, t, "Suppression reussie !", QMessageBox::Ok);
        }
        else
        {
            QMessageBox::critical(this, t, "Echec de Suppression !");
        }
    }
    else
    {
        this->close();
    }
}
