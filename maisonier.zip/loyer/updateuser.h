#ifndef UPDATEUSER_H
#define UPDATEUSER_H
#include <QWidget>
#include <QMainWindow>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QLabel>
#include <QLineEdit>
#include <QDateEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QMessageBox>
#include <QMenuBar>
#include <QCloseEvent>
#include <QGroupBox>
#include <QSqlTableModel>
#include <QSqlQuery>
#include <QTableView>
#include <QGridLayout>
#include <QDebug>
#include <QSqlError>

class UpdateUser:public QWidget
{
    Q_OBJECT

protected:
    QLineEdit *LEdit_nom;
    QLineEdit *LEdit_login;
    QLineEdit *LEdit_password;
    QLineEdit *LEdit_passwordC;
    QLineEdit *LEdit_tel;
    QPushButton *btn_renitial;
    QPushButton *btn_enreg;
    QPushButton *btn_fermer;
    QHBoxLayout *cadreHbtn;
    QVBoxLayout *cadrev;
    QFormLayout *mon_form;
    QGroupBox *grp_option;
    QGroupBox *grp_formulaire;
    int id_user;

public:
    UpdateUser(QString t="Modifier un Utilisateur", QWidget *parent = NULL);
    void ihmshow(int idUser, QString t="Mis a jour d'un utilisateur", QWidget *parent = NULL);
    void ihmDelete(int iduser, QString t="Suppression d'un utilisateur", QWidget *parent = NULL);

public slots:
    void envoyerForm();
};

#endif // UPDATEUSER_H
