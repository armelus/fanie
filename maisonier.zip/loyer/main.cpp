#include <QApplication>
#include <QSqlDatabase>
#include <QSqlError>
#include <QMessageBox>
#include <QSqlQuery>
#include <QCryptographicHash>
#include <QString>
#include <QByteArray>
#include <QMessageBox>
#include "fenprincipale.h"


#define SEL_AVANT "D4DQDZ68$E" // une technique approuvée pour nos sels est de s'endormir sur le clavier
#define SEL_APRES "7HHo£hh7YH" //Si ils ne veulent rien dire, c'est mieux.


int main(int argc, char *argv[])
{
    QApplication appli (argc, argv);
    QSqlDatabase db=QSqlDatabase::addDatabase("QODBC");
    db.setDatabaseName("postgresql"); // DSN que nous venons de créer.

    if(!db.open())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"), db.lastError().text());
    }else

        QMessageBox::information(0, QObject::tr("connecté"),"connecter");

    FenPrincipale toi;
    toi.setVisible(true);

    return appli.exec();

}
