#ifndef UTILISATEUR_H
#define UTILISATEUR_H
#include <QWidget>
#include <QMainWindow>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QLabel>
#include <QLineEdit>
#include <QDateEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QMessageBox>
#include <QMenuBar>
#include <QCloseEvent>
#include <QGroupBox>
#include <QSqlTableModel>
#include <QTableView>
#include <QGridLayout>



class Utilisateur:public QWidget
{
    Q_OBJECT

protected:
    QLineEdit *LEdit_nom;
    QLineEdit *LEdit_login;
    QLineEdit *LEdit_password;
    QLineEdit *LEdit_passwordC;
    QLineEdit *LEdit_tel;
    QPushButton *btn_renitial;
    QPushButton *btn_enreg;
    QPushButton *btn_fermer;
    QHBoxLayout *cadreHbtn;
    QVBoxLayout *cadrev;
    QFormLayout *mon_form;
    QGroupBox *grp_option;
    QGroupBox *grp_formulaire;





public:
    Utilisateur(QString t="Créer un  Utilisateur", QWidget *parent = NULL);
    void UpdateUtilisateur(int idUser, QString t="Mis a jour des informations d'un Utilisateur", QWidget *parent = NULL);
     void closeEvent(QCloseEvent *evt);


public slots:
    void Renitialiser();
    void EnregForm();
    void GestionFermeture();
    void EnvoyerForm();
    void UpdateUser();


};
#endif // UTILISATEUR_H
