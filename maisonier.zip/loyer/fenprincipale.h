#ifndef FENPRINCIPALE_H
#define FENPRINCIPALE_H
#include <QMessageBox>
#include <QMainWindow> //ça inclu dejà QMenuBar
#include <QMenuBar> //Mais c'est essentiel de mettre.
#include <QCloseEvent>// pour gérer les événements
#include <QIcon>
#include <QGroupBox>
#include <QLabel>
#include <QWidget>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QLineEdit>
#include <QDateEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QMessageBox>
#include <QMainWindow>
#include "Authentification.h"



class FenPrincipale:public QMainWindow
{
    Q_OBJECT
// Methodes

public:
 FenPrincipale(QString e="LE MAISONIER", QWidget *parent=NULL);

//    void closeEvent(QCloseEvent *evt);// masquage de la fonction pour gérer les événement de la ferméture des fenêtres.


protected:

    QPushButton *Btn_connect;
    QPushButton *Btn_Quitter;
    QFormLayout *CadreF;
    QWidget *WidgetFen;


public slots:// c'est Q_OBJECT qui permet de réaliser cette partie; donc ne pas oublier

    void AfficheAuthentification();

};
#endif // FENPRINCIPALE_H
