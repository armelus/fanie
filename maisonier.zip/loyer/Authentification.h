#ifndef Authentification_H
#define Authentification_H

#include <QWidget>
#include <QString>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QFormLayout>
#include <QMessageBox>
#include <QSqlQuery>
#include <QCloseEvent>

class Authentification : public QWidget
{

    Q_OBJECT//toujours en première ligne. Pour permettre de creer ses propres SIGNALS et SLOTS.
    //Ne pas oublier d'exécuter qmake (la première fois).

    //attributs
protected:
    //QString titre;
    QLabel *libelleAuthention;//libellé de la fenetre
    QLineEdit *login;
    QLineEdit *mot_depasse;
    QPushButton *Btn_connexion;
    QFormLayout *Form_layout;
    QLabel *echec;
    QLineEdit *nom_complet;
    QGridLayout *grid;


    // Methodes
public:

    Authentification(QString e="Page d'authentification", QWidget *parent=NULL);

public slots:
    void connectBD();

};

#endif // Authentification_H

