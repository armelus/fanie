#ifndef LISTEUTILISATEURS_H
#define LISTEUTILISATEURS_H

#include <QWidget>
#include <QSql>
#include <QSqlQuery>
#include <QString>
#include <QSqlTableModel>
#include <QSqlQueryModel>
#include <QDebug>

namespace Ui {
class ListeUtilisateurs;
}

class ListeUtilisateurs : public QWidget
{
    Q_OBJECT

public:
    explicit ListeUtilisateurs(QWidget *parent = 0);
    ~ListeUtilisateurs();

private slots:
    void on_modifier_clicked();

    void on_supprimer_clicked();

private:
    Ui::ListeUtilisateurs *ui;
    //QSqlTableModel *model;
    QSqlQueryModel *model;
};

#endif // LISTEUTILISATEURS_H
