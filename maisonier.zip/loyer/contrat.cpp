#include "contrat.h"
#include "ui_contrat.h"

Contrat::Contrat(int idUser, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Contrat)
{
    ui->setupUi(this);
    this->id_user = idUser;
    this->initializeView();
}

Contrat::~Contrat()
{
    delete ui;
}

void Contrat::initializeView()
{
    model = new QSqlRelationalTableModel;
    model->setTable("contrat");
    model->setRelation(1, QSqlRelation("occupation", "id_occup", "id_occup"));
    model->setRelation(2, QSqlRelation("utilisateur", "id_user", "nom_complet"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Occupation"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Bailleur"));
    model->select();

    this->ui->tableView->setModel(model);
    this->ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    //this->ui->tableView->setColumnHidden(0, true);
    //this->ui->tableView->setColumnHidden(1, true);
    //this->ui->tableView->setColumnHidden(2, true);
}

void Contrat::ihmInsert()
{
    fenetre = new QWidget;
    btn_enreg = new QPushButton("Enregistrer");
    btn_fermer = new QPushButton("Fermer") ;
    cadreHbtn = new QHBoxLayout ;
    cadrev = new QVBoxLayout ;
    mon_form = new QFormLayout ;
    occupations = new QComboBox;

    vector<int> listeHabitants;
    vector<int>::iterator it;

    QSqlQuery queryHabitant, queryOccupation;

    queryHabitant.prepare("SELECT id_habit FROM habitant WHERE id_user = :id");
    queryHabitant.bindValue(":id", this->id_user);
    if(queryHabitant.exec())
    {
        while(queryHabitant.next())
        {
            int id = queryHabitant.value(0).toInt();
            listeHabitants.push_back(id);
        }
    }
    else
    {
        qDebug() << queryHabitant.lastError().text();
    }

    for(it = listeHabitants.begin(); it != listeHabitants.end(); ++it)
    {
        queryOccupation.prepare("SELECT id_occup, loyer_de_base FROM occupation WHERE id_habit = :id ORDER BY id_occup ASC");
        queryOccupation.bindValue(":id", *it);

        if(queryOccupation.exec())
        {
            while(queryOccupation.next())
            {
                QString libelle = QString("%1 - %2").arg(queryOccupation.value(0).toString()).arg(queryOccupation.value(1).toString());
                occupations->addItem(libelle);
            }
        }
        else
        {
            qDebug() << queryOccupation.lastError().text();
        }
    }

    mon_form->addRow("Choisir l'occupation", occupations);

    cadreHbtn->addWidget(btn_enreg);
    cadreHbtn->addWidget(btn_fermer);

    cadrev->addLayout(mon_form);
    cadrev->addLayout(cadreHbtn);

    this->fenetre->setLayout(cadrev);
    this->fenetre->setWindowModality(Qt::ApplicationModal);
    this->fenetre->setWindowTitle("Ajout d'un nouveau contrat de bail");
    this->fenetre->show();

    connect(btn_enreg, SIGNAL(clicked()), this, SLOT(enregistrer()));
    connect(btn_fermer, SIGNAL(clicked()), this->fenetre, SLOT(close()));
}

void Contrat::ihmUpdate()
{
    fenetre = new QWidget;
    btn_enreg = new QPushButton("Enregistrer");
    btn_fermer = new QPushButton("Fermer") ;
    cadreHbtn = new QHBoxLayout ;
    cadrev = new QVBoxLayout ;
    mon_form = new QFormLayout ;

    DateRenouvellement = new QDateEdit;
    DateRenouvellement->setCalendarPopup(true);
    DateRenouvellement->setMaximumDate(QDate::currentDate());

    QSqlQuery query;
    query.prepare("SELECT date_de_renouvellement_du_bail FROM contrat WHERE id_contrat = :id");
    query.bindValue(":id", this->id_contrat);

    if(query.exec())
    {
        while(query.next())
        {
            QString date = query.value(0).toString();
            DateRenouvellement->setDate(QDate::fromString(date, "dd/MM/yyyy"));
        }
    }

    mon_form->addRow("Date de renouvellement du bail", DateRenouvellement);

    cadreHbtn->addWidget(btn_enreg);
    cadreHbtn->addWidget(btn_fermer);

    cadrev->addLayout(mon_form);
    cadrev->addLayout(cadreHbtn);

    this->fenetre->setLayout(cadrev);
    this->fenetre->setWindowModality(Qt::ApplicationModal);
    this->fenetre->setWindowTitle("Modification d'un contrat de bail");
    this->fenetre->show();

    connect(btn_enreg, SIGNAL(clicked()), this, SLOT(update()));
    connect(btn_fermer, SIGNAL(clicked()), this->fenetre, SLOT(close()));
}

void Contrat::supprimer()
{
    int choix = QMessageBox::question(this,"confirmation de la suppression","voulez_vous vraiment supprimer ce contrat ?", QMessageBox::Yes|QMessageBox::No,QMessageBox::No);

    if(choix == QMessageBox::Yes)
    {
        QSqlQuery query;
        query.prepare("DELETE FROM contrat WHERE id_contrat = :id");
        query.bindValue(":id", this->id_contrat);

        if(query.exec())
        {
            query.next();
            QMessageBox::information(this,"Suppression du Contrat","Suppression réussie",QMessageBox::Ok);
        }
    }

    this->initializeView();
}

void Contrat::resilier()
{
    QSqlQuery query;

    query.prepare("UPDATE contrat SET date_de_resiliation = NOW() WHERE id_contrat = :id");
    query.bindValue(":id", this->id_contrat);

    if(query.exec())
    {
        query.next();
        QMessageBox::information(this,"Résiliation d'un contrat","Résiliation réussie ! Vous ne pourrez plus renouveller ce contrat",QMessageBox::Ok);
        this->initializeView();
    }
    else
    {
        qDebug() << query.lastError().text();
    }
}

void Contrat::renouveler()
{
    QString dateResiliation;
    QSqlQuery resiliation, query;

    resiliation.prepare("SELECT date_de_resiliation FROM contrat WHERE id_contrat = :id");
    resiliation.bindValue(":id", this->id_contrat);
    if(resiliation.exec())
    {
        while(resiliation.next())
        {
            dateResiliation = resiliation.value(0).toString();
            qDebug() << dateResiliation;
        }
    }
    else
    {
        qDebug() << resiliation.lastError().text();
    }

    if(dateResiliation.isEmpty())
    {
        query.prepare("UPDATE contrat SET date_de_renouvellement_du_bail = NOW() WHERE id_contrat = :id");
        query.bindValue(":id", this->id_contrat);

        if(query.exec())
        {
            query.next();
            QMessageBox::information(this,"Re nouvellement d'un contrat","Contrat renouveller avec succès !",QMessageBox::Ok);
            this->initializeView();

        }
        else
        {
            qDebug() << query.lastError().text();
        }
    }
    else
    {
        QMessageBox::warning(this, "Echec de Renouvellement", "Ce contrat a déjà été résilier. Impossible de le renouveler !", QMessageBox::Ok);
    }
}

void Contrat::on_ajouter_clicked()
{
    this->ihmInsert();
}

void Contrat::on_modifier_clicked()
{
    QItemSelectionModel *selection = this->ui->tableView->selectionModel();
    QModelIndexList indexes = selection->selectedIndexes();
    QModelIndex index = indexes.at(0);
    QVariant element = model->data(index, Qt::DisplayRole);

    id_contrat = element.toInt();
    this->ihmUpdate();
}

void Contrat::on_supprimer_clicked()
{
    QItemSelectionModel *selection = this->ui->tableView->selectionModel();
    QModelIndexList indexes = selection->selectedIndexes();
    QModelIndex index = indexes.at(0);
    QVariant element = model->data(index, Qt::DisplayRole);

    id_contrat = element.toInt();
    this->supprimer();
}

void Contrat::enregistrer()
{
    QString occupationSTR = occupations->currentText();
    QString occupationIDSTR = occupationSTR.at(0);
    this->id_occupation = occupationIDSTR.toInt();
    double loyer;

    QSqlQuery query, queryOccupation;

    queryOccupation.prepare("SELECT loyer_de_base FROM occupation WHERE id_occup = :id");
    queryOccupation.bindValue(":id", this->id_occupation);
    if(queryOccupation.exec())
    {
        while(queryOccupation.next())
        {
            loyer = queryOccupation.value(0).toDouble();
        }
    }
    else
    {
        qDebug() << queryOccupation.lastError().text();
    }


    query.prepare("INSERT INTO contrat(id_occup, id_user, date_de_creation, montant_mensuel) VALUES(:occupation, :user, NOW(), :loyer)");
    query.bindValue(":occupation", this->id_occupation);
    query.bindValue(":user", this->id_user);
    query.bindValue(":loyer", loyer);

    if(query.exec())
    {
        query.next();
        QMessageBox::information(this,"Enregistrement d'un Contrat","Enregistement réussie",QMessageBox::Ok);
        this->fenetre->close();
        this->initializeView();
    }
    else
    {
        qDebug() << query.lastError().text();
    }

}

void Contrat::update()
{
    QString dateResiliation;
    QSqlQuery resiliation, query;

    resiliation.prepare("SELECT date_de_resiliation FROM contrat WHERE id_contrat = :id");
    resiliation.bindValue(":id", this->id_contrat);
    if(resiliation.exec())
    {
        while(resiliation.next())
        {
            dateResiliation = resiliation.value(0).toString();
        }
    }
    else
    {
        qDebug() << resiliation.lastError().text();
    }

    if(dateResiliation.isEmpty())
    {
        QString dateRenew = DateRenouvellement->text();

        QSqlQuery query;

        query.prepare("UPDATE contrat SET date_de_renouvellement_du_bail = :date WHERE id_contrat = :id");
        query.bindValue(":id", this->id_contrat);
        query.bindValue(":date", dateRenew);

        if(query.exec())
        {
            query.next();
            QMessageBox::information(this,"Modifiaction d'un contrat","Contrat modifier avec succès !",QMessageBox::Ok);
            this->fenetre->close();
            this->initializeView();
        }
        else
        {
            qDebug() << query.lastError().text();
        }
    }
    else
    {
        QMessageBox::warning(this, "Echec d'operation", "Ce contrat a déjà été résilier. Impossible de le Modifier!", QMessageBox::Ok);
    }

}

void Contrat::on_resilier_clicked()
{
    QItemSelectionModel *selection = this->ui->tableView->selectionModel();
    QModelIndexList indexes = selection->selectedIndexes();
    QModelIndex index = indexes.at(0);
    QVariant element = model->data(index, Qt::DisplayRole);

    id_contrat = element.toInt();
    this->resilier();
}

void Contrat::on_renouveler_clicked()
{
    QItemSelectionModel *selection = this->ui->tableView->selectionModel();
    QModelIndexList indexes = selection->selectedIndexes();
    QModelIndex index = indexes.at(0);
    QVariant element = model->data(index, Qt::DisplayRole);

    id_contrat = element.toInt();
    this->renouveler();
}
