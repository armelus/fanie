#include "occupation.h"
#include "ui_occupation.h"

Occupation::Occupation(int idUser, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Occupation)
{
    ui->setupUi(this);
    this->id_user = idUser;
    this->initializeView();
}

Occupation::~Occupation()
{
    delete ui;
}

void Occupation::initializeView()
{
    model = new QSqlTableModel;
    model->setTable("occupation");
    model->select();

    this->ui->tableView->setModel(model);
    this->ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    this->ui->tableView->setColumnHidden(0, true);
    this->ui->tableView->setColumnHidden(1, true);
    this->ui->tableView->setColumnHidden(2, true);
    this->ui->tableView->setColumnHidden(6, true);
}

void Occupation::ihmNewOccupation(QWidget *parent, QString title)
{
    fenetre = new QWidget;
    habitants = new QComboBox;
    logements = new QComboBox;
    LoyerBase = new QLineEdit;
    DateEntree = new QDateEdit ;
    DateSortie = new QDateEdit ;
    arriere = new QLineEdit ;
    Description = new QTextEdit ;
    btn_renitial = new QPushButton("Rénitialiser");
    btn_enreg = new QPushButton("Enregistrer");
    btn_fermer = new QPushButton("Fermer") ;
    cadreHbtn = new QHBoxLayout ;
    cadrev = new QVBoxLayout ;
    mon_form = new QFormLayout ;


    QSqlQuery queryHabitant, queryLogement;

    queryHabitant.exec("SELECT * FROM habitant WHERE etat = 0");
    while(queryHabitant.next())
    {
        QString id = queryHabitant.value(0).toString();
        QString nom = queryHabitant.value(2).toString();
        QString prenom = queryHabitant.value(3).toString();
        QString habitant = QString("%1 - %2 %3").arg(id).arg(nom).arg(prenom);
        habitants->addItem(habitant);
    }

    queryLogement.exec("SELECT * FROM logement WHERE etat = 0");
    while(queryLogement.next())
    {
        QString id = queryLogement.value(0).toString();
        QString type = queryLogement.value(2).toString();
        prixMin = queryLogement.value(5).toDouble();
        prixMax = queryLogement.value(6).toDouble();
        QString logement = QString("%1 - %2").arg(id).arg(type);
        logements->addItem(logement);
    }

    LoyerBase->setMaxLength(9);
    LoyerBase->setPlaceholderText("saisissez un montant");
    LoyerBase->setInputMask("999999999");

    DateEntree->setCalendarPopup(true);
    DateEntree->setDate(QDate::currentDate());
    DateSortie->setCalendarPopup(true);
    DateSortie->setDate(QDate::currentDate());

    arriere->setMaxLength(9);
    arriere->setPlaceholderText("999999999");
    arriere->setPlaceholderText("entrez le montant des arriérés");

    mon_form->addRow("Choisir l'habitant", habitants);
    mon_form->addRow("Choisir Le logment", logements);
    mon_form->addRow("Loyer de base:", LoyerBase);
    mon_form->addRow("Date d'entrée:" , DateEntree);
    mon_form->addRow("Date de sortie", DateSortie);
    mon_form->addRow("Arriéré de loyer", arriere);
    mon_form->addRow("Observation", Description);


    cadreHbtn->addWidget(btn_renitial);
    cadreHbtn->addWidget(btn_enreg);
    cadreHbtn->addWidget(btn_fermer);


    cadrev->addLayout(mon_form);
    cadrev->addLayout(cadreHbtn);

    this->fenetre->setLayout(cadrev);
    this->fenetre->setWindowModality(Qt::ApplicationModal);
    this->fenetre->setWindowTitle(title);
    this->fenetre->show();

    connect(btn_enreg, SIGNAL(clicked()), this, SLOT(enregistrer()));
}

void Occupation::ihmUpdate(QString title)
{
    fenetre = new QWidget;
    habitants = new QComboBox;
    logements = new QComboBox;
    LoyerBase = new QLineEdit;
    DateEntree = new QDateEdit ;
    DateSortie = new QDateEdit ;
    arriere = new QLineEdit ;
    Description = new QTextEdit ;
    btn_renitial = new QPushButton("Rénitialiser");
    btn_enreg = new QPushButton("Enregistrer");
    btn_fermer = new QPushButton("Fermer") ;
    cadreHbtn = new QHBoxLayout ;
    cadrev = new QVBoxLayout ;
    mon_form = new QFormLayout ;
    etat = new QCheckBox;

    QSqlQuery queryHabitant, queryLogement, queryOccupation;
    double loyer, arriereD;
    int state;
    QString description, entreeSTR, sortieSTR;

    queryLogement.exec("SELECT * FROM logement WHERE etat = 0");
    while(queryLogement.next())
    {
        QString id = queryLogement.value(0).toString();
        QString type = queryLogement.value(2).toString();
        prixMin = queryLogement.value(5).toDouble();
        prixMax = queryLogement.value(6).toDouble();
        QString logement = QString("%1 - %2").arg(id).arg(type);
        logements->addItem(logement);
    }

    queryOccupation.prepare("SELECT * FROM occupation WHERE id_occup = :id");
    queryOccupation.bindValue(":id", this->id_occupation);
    if(queryOccupation.exec())
    {
        while(queryOccupation.next())
        {
            this->id_habit = queryOccupation.value(2).toInt();
            loyer = queryOccupation.value(3).toDouble();
            arriereD = queryOccupation.value(8).toDouble();
            entreeSTR = queryOccupation.value(4).toString();
            sortieSTR = queryOccupation.value(5).toString();
            state = queryOccupation.value(6).toInt();
            description = queryOccupation.value(7).toString();
        }
    }
    qDebug() << entreeSTR << sortieSTR;
    queryHabitant.prepare("SELECT * FROM habitant WHERE id_habit = :id");
    queryHabitant.bindValue(":id", this->id_habit);
    if(queryHabitant.exec())
    {
        while(queryHabitant.next())
        {
            QString id = queryHabitant.value(0).toString();
            QString nom = queryHabitant.value(2).toString();
            QString prenom = queryHabitant.value(3).toString();
            QString habitant = QString("%1 - %2 %3").arg(id).arg(nom).arg(prenom);
            habitants->addItem(habitant);
        }
    }


    LoyerBase->setMaxLength(9);
    LoyerBase->setText(QString::number(loyer));
    LoyerBase->setPlaceholderText("saisissez un montant");
    LoyerBase->setInputMask("999999999");

    DateEntree->setCalendarPopup(true);
    DateEntree->setDate(QDate::fromString(entreeSTR, "dd/MM/yyyy"));
    DateSortie->setCalendarPopup(true);
    DateSortie->setDate(QDate::fromString(sortieSTR, "dd/MM/yyyy"));

    arriere->setMaxLength(9);
    arriere->setText(QString::number(arriereD));
    arriere->setPlaceholderText("999999999");
    arriere->setPlaceholderText("entrez le montant des arriérés");

    Description->setText(description);

    if(state == 0)
        etat->setCheckState(Qt::Unchecked);
    else
        etat->setCheckState(Qt::Checked);

    mon_form->addRow("Choisir l'habitant", habitants);
    mon_form->addRow("Choisir Le logment", logements);
    mon_form->addRow("Loyer de base:", LoyerBase);
    mon_form->addRow("Date d'entrée:" , DateEntree);
    mon_form->addRow("Date de sortie", DateSortie);
    mon_form->addRow("Arriéré de loyer", arriere);
    mon_form->addRow("Observation", Description);
    mon_form->addRow("Occupé", etat);

    cadreHbtn->addWidget(btn_renitial);
    cadreHbtn->addWidget(btn_enreg);
    cadreHbtn->addWidget(btn_fermer);


    cadrev->addLayout(mon_form);
    cadrev->addLayout(cadreHbtn);

    this->fenetre->setLayout(cadrev);
    this->fenetre->setWindowModality(Qt::ApplicationModal);
    this->fenetre->setWindowTitle(title);
    this->fenetre->show();

    connect(btn_enreg, SIGNAL(clicked()), this, SLOT(update()));
    connect(btn_fermer, SIGNAL(clicked()), this->fenetre, SLOT(close()));
}

void Occupation::on_ajouter_clicked()
{
    this->ihmNewOccupation(this);
}

void Occupation::on_modifier_clicked()
{
    QItemSelectionModel *selection = this->ui->tableView->selectionModel();
    QModelIndexList indexes = selection->selectedIndexes();
    QModelIndex indexOccupation = indexes.at(0);
    QModelIndex indexHabitant = indexes.at(2);
    QVariant elementOccupation = model->data(indexOccupation, Qt::DisplayRole);
    QVariant elementHabitant = model->data(indexHabitant, Qt::DisplayRole);

    id_occupation = elementOccupation.toInt();
    id_habit = elementHabitant.toInt();
    this->ihmUpdate();
}

void Occupation::on_supprimer_clicked()
{
    QItemSelectionModel *selection = this->ui->tableView->selectionModel();
    QModelIndexList indexes = selection->selectedIndexes();
    QModelIndex index = indexes.at(0);
    QVariant element = model->data(index, Qt::DisplayRole);

    id_occupation = element.toInt();
    this->supprimer();
}

void Occupation::enregistrer()
{
    QString habit = habitants->currentText();
    QString idHabitantStr = habit.at(0);
    int idHabitant = idHabitantStr.toInt();

    QString loge = logements->currentText();
    QString idLoge = loge.at(0);
    int idLogement = idLoge.toInt();
    QString arrSTR = arriere->text();
    double arr = arriere->text().toDouble();

    if(arrSTR.isEmpty())
        arr = 0;

    QSqlQuery query;
    query.prepare("INSERT INTO occupation(id_loge, id_habit, loyer_de_base, date_entree, date_sortie, etat, description, arriere) VALUES(:loge, :habit, :loyer, :entree, :sortie, :etat, :desc, :arriere)");
    query.bindValue(":loge", idLogement);
    query.bindValue(":habit", idHabitant);
    query.bindValue(":loyer", LoyerBase->text().toDouble());
    query.bindValue(":entree", DateEntree->date().toString("dd-MM-yyyy"));
    query.bindValue(":sortie", DateSortie->date().toString("dd-MM-yyyy"));
    query.bindValue(":etat", 1);
    query.bindValue(":desc", Description->toPlainText());
    query.bindValue(":arriere", arr);

    if(query.exec())
    {
        query.next();
        QMessageBox::information(this,"Enregistrement d'une Occupation","Enregistement réussie",QMessageBox::Ok);
        this->fenetre->close();
        this->initializeView();
    }
    else
    {
        qDebug() << query.lastError().text();
    }
}

void Occupation::update()
{
    QString loge = logements->currentText();
    QString idLoge = loge.at(0);
    int idLogement = idLoge.toInt();
    QString arrSTR = arriere->text();
    double arr = arriere->text().toDouble();

    int state = 0;

    if(arrSTR.isEmpty())
        arr = 0;

    if(etat->isChecked())
        state = 1;

    QSqlQuery query;

    query.prepare("UPDATE occupation SET id_loge = :logement, loyer_de_base = :loyer, date_entree = :entree, date_sortie = :sortie, etat = :etat, description = :desc, arriere = :arriere WHERE id_occup = :id");
    query.bindValue(":id", id_occupation);
    query.bindValue(":logement", idLogement);
    query.bindValue(":loyer", LoyerBase->text().toDouble());
    query.bindValue(":entree", DateEntree->date().toString("dd-MM-yyyy"));
    query.bindValue(":sortie", DateSortie->date().toString("dd-MM-yyyy"));
    query.bindValue(":etat", state);
    query.bindValue(":desc", Description->toPlainText());
    query.bindValue(":arriere", arr);

    if(query.exec())
    {
        query.next();
        QMessageBox::information(this,"Mis à jour d'une Occupation","Mis à jour réussie",QMessageBox::Ok);
        this->fenetre->close();
        this->initializeView();
    }
    else
    {
        qDebug() << query.lastError().text();
    }
}

void Occupation::supprimer()
{
    int choix = QMessageBox::question(this,"confirmation de la suppression","voulez_vous vraiment supprimer cette occupation ?", QMessageBox::Yes|QMessageBox::No,QMessageBox::No);

    if(choix == QMessageBox::Yes)
    {
        QSqlQuery query;
        query.prepare("DELETE FROM occupation WHERE id_occup = :id");
        query.bindValue(":id", this->id_occupation);

        if(query.exec())
        {
            query.next();
            QMessageBox::information(this,"Suppression de l'Occupation","Suppression réussie",QMessageBox::Ok);
        }
    }

    this->initializeView();
}
