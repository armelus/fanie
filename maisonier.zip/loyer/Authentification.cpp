#include<QLineEdit>
#include<QSqlDatabase>
#include<QSqlError>
#include<QMessageBox>
#include <QCryptographicHash>
#include<QSqlQuery>
#include<QDebug>
#include "Authentification.h"
#include "accueil.h"



Authentification::Authentification(QString e, QWidget *parent)
{
    // Création des variables dynamiques(pointeurs)
    //titre=new QString;
    libelleAuthention = new QLabel ;//libellé de la fenetre
    login = new QLineEdit;
    mot_depasse = new QLineEdit;
    Btn_connexion = new QPushButton;
    Form_layout = new QFormLayout;
    echec = new QLabel;
    nom_complet=new QLineEdit;



    this->setWindowTitle(e);


    //paramétrage du libellé
    libelleAuthention->setText("Connectez-vous ici");
    QFont fonte("arial",10);
    fonte.setBold(true);
    libelleAuthention->setFont(fonte);
    QPalette pal;
    pal.setColor(QPalette::WindowText,Qt::black);
    libelleAuthention->setPalette(pal);

    //paramétrage du champ login
    login->setMaxLength(20);// bloquer la taille de la saisie.
    login->setPlaceholderText("Saisissez votre login ici");

    //Paramétrage du chamP password
    mot_depasse->setMaxLength(30);// pas plus de 30 caracteres
    // mot_depasse->setReadOnly(true);// pour bloquer la saisie
    mot_depasse->setPlaceholderText("Saisissez votre mot de passe ici");
    // texte qui apparait dans la zone de saisie mais quand tu cliques ça quitte
    mot_depasse->setEchoMode(QLineEdit::Password);//pour masquer la saisie.
    // par défaut c'est c'est  normal  la place de Password.

    //paramétrage des boutons.
    Btn_connexion->setText(" Connexion ");
    Btn_connexion->setToolTip(" Cliquez ici vous connecter à votre compte ");


    //Paramétrage du cadre formulaire.
    Form_layout->addRow(libelleAuthention);//insérer la ligne libAuthentification dans le formulaire.
    Form_layout->addRow(" Login: ",login);
    // addRow permet d'ajouter une zone de saisie horizontale de saisie de texte.
    Form_layout->addRow(" Mot de passe: ",mot_depasse);
    Form_layout->addRow(Btn_connexion);


    //Paramétrage de la fenetre
    // setWindowTitle(titre);// Faire apparaitre le titre de la fenetre.
    this->setLayout(Form_layout);//Faire apparaitre le formulaire.
    this->setFixedSize(280,120);
    //setWindowIcon(QIcon("dony.PNG"));

    //Paramétrage des connexions
    connect(Btn_connexion,SIGNAL(clicked()),this,SLOT(connectBD()));
    //connect(Btn_close,SIGNAL(clicked()),this,SLOT(GestionFermeture()));
    // this c'est le receptur du message(notre fenetre).
    //connect(Mon_Slider,SIGNAL(valueChanged(int)),BarreAvance,SLOT(setValue(int)));//


}

void Authentification::connectBD()

{
    QString h = login->text();
    QString t = mot_depasse->text();

    if(h.isEmpty()||t.isEmpty())
        QMessageBox::critical(this,"Erreur","Tous les champs sont obligatoires",QMessageBox::Ok);
    else
    {
        QSqlQuery req,up;
        req.exec("select login , mot_depasse,nom_complet,id_user,nbre_connex from utilisateur ");
        qDebug() << req.lastError().text();

        while (req.next())
        {//variable duc combo.additem(req.value(o)toString())
            int id=req.value(3).toInt();
            int nombre=req.value(4).toInt();
            int total=nombre+1;
            QString nom=req.value(2).toString();

            QString pass;
            pass = t;
            pass = QString("%1").arg(QString(QCryptographicHash::hash(mot_depasse->text().toUtf8(),QCryptographicHash::Md5).toHex()));

            if(h ==req.value(0) && pass == req.value(1))
            {
                accueil *kl= new accueil(nom,id);
                kl->setWindowModality(Qt::ApplicationModal);
                kl->show();
                up.prepare("update utilisateur set date_derniere_connex=now(),nbre_connex=:total where id_user=:id");
                up.bindValue(":total", total);
                up.bindValue(":id",id);
                up.exec();
                close();
            }
            else
            {
                //QSqlError.ConnectionError();

                echec->setText("Combinaison Login, mot de passe incorrect");
                //QMessageBox::warning(this,"ERREUR","Login ou mot de pass incorecte",QMessageBox::Ok);
                qDebug() << req.lastError();
            }
        }
    }
}
